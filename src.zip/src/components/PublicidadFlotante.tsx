// components/PublicidadChatbot.tsx
"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Image from "next/image";
import { X } from "lucide-react";

const GPT_ROBOTIC_URL = "https://www.gptrobotic.com/";
const IMG_SRC = "/chatbot.png";
 // <-- ruta de tu imagen dentro de /public

export default function PublicidadChatbot() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    // Aparece a los 2s, se oculta a los 6 minutos (ajustable)
    const showTimer = setTimeout(() => setVisible(true), 2000);
    const hideTimer = setTimeout(() => setVisible(false), 6 * 60 * 1000);
    return () => {
      clearTimeout(showTimer);
      clearTimeout(hideTimer);
    };
  }, []);

  const goToGptRobotic = () => {
    window.open(GPT_ROBOTIC_URL, "_blank", "noopener,noreferrer");
  };

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ opacity: 0, y: 50, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 50, scale: 0.95 }}
          transition={{ type: "spring", stiffness: 260, damping: 20 }}
          className="fixed bottom-6 right-6 z-50 w-80 cursor-pointer select-none"
          onClick={goToGptRobotic}
          aria-label="Publicidad: Ir a GPT Robotic"
          role="button"
        >
          <div className="overflow-hidden rounded-2xl shadow-2xl bg-white">
            {/* Imagen superior */}
            <div className="relative h-44 w-full">
              <Image
                src={IMG_SRC}
                alt="Asesora atendiendo por WhatsApp / Chatbot"
                fill
                priority
                sizes="(max-width: 768px) 80vw, 20vw"
                className="object-cover"
              />
            </div>

            {/* Cuerpo / Copy */}
            <div className="p-4 bg-gradient-to-br from-purple-600 to-indigo-700 text-white">
              <h4 className="text-lg font-bold leading-tight">
                ¡Crea tu Chatbot Hoy!
              </h4>
              <p className="mt-1 text-sm opacity-95">
                Un asistente inteligente en WhatsApp atiende a tus clientes 24/7.
                Planes desde <strong>49,99&nbsp;USD/mes</strong>, sin costo de implementación 🚀
              </p>

              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation(); // no dispare el click del contenedor
                  goToGptRobotic();
                }}
                className="mt-3 w-full rounded-xl bg-white px-4 py-2 font-semibold text-purple-700 shadow hover:bg-gray-100 transition"
              >
                ¡Ir a GPT Robotic!
              </button>
            </div>
          </div>

          {/* Botón cerrar */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation(); // evita abrir el link
              setVisible(false);
            }}
            className="absolute -top-2 -right-2 rounded-full bg-black/70 p-1.5 text-white hover:bg-black/85"
            aria-label="Cerrar publicidad"
          >
            <X className="h-4 w-4" />
          </button>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
